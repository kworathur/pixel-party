#!/bin/bash 
npm start


# In another window 
wscat -c "ws://127.0.0.1:8081"

# {"x": 0, "y": 2, "r": 255, "g": 255, "b": 255}
# Try sending before cooldown 

# out of bounds 
# {"x": 256, "y": 0, "r": 255, "g", 255, "b": 255}


# invalid RGB combination 
# {"x": 0, "y": 2, "r": 255, "g": 255, "b": 255}

